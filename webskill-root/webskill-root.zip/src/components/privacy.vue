<!--
版权隐私
-->
<template>
  <section class="copyright">
     <h1 class="crTitle">关于本站</h1>
      <div class="crCon">
         本站点所有页面的版式、图片版权、代码等均为本站所有，未经授权，不得用于除本此之外的任何场所及转载,对于注明可转载的请务必转载时注明来源。
         <br/>
         <br/>
          本隐私条款的修改及更新权均属于个人所有。
          <br/>
          <br/>
          感谢您的支持与配合。
      </div>
      <p class="thanks">
        此致：谢礼！！！
      </p>
  </section>
  
</template>
<style lang="scss" scoped>
.copyright{
  padding: .2rem;
  font-size: .18rem;
  background: #fff;
  .crTitle{
     font-size: .18rem;
     color:#0ab120;
  }
  .crCon{
    font-size:.14rem;
    line-height: .24rem;
    margin-top:20px;
    color:#666;
  }
  .thanks{
   font-size:.20rem;
   margin-top: 20px;
   color: blueviolet;
  }
}
</style>

